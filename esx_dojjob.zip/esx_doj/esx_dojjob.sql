INSERT INTO `addon_account` (name, label, shared) VALUES 
	('society_doj','DOJ',1)
;

INSERT INTO `datastore` (name, label, shared) VALUES 
	('society_doj','DOJ',1)
;

INSERT INTO `addon_inventory` (name, label, shared) VALUES 
	('society_doj', 'DOJ', 1)
;

INSERT INTO `jobs` (`name`, `label`, `whitelisted`) VALUES
('doj', 'doj', 1);

--
-- Déchargement des données de la table `jobs_grades`
--

INSERT INTO `job_grades` (`job_name`, `grade`, `name`, `label`, `salary`, `skin_male`, `skin_female`) VALUES
('doj', 0, 'recruit', 'Praktikant', 1500, '{}', '{}'),
('doj', 1, 'anwalt', 'Anwalt', 1800, '{}', '{}'),
('doj', 2, 'staatsanwalt', 'Staatsanwalt', 2100, '{}', '{}'),
('doj', 3, 'richter', 'Richter', 2700, '{}', '{}'),
('doj', 4, 'boss', 'Leiter des DOJ', 2700, '{}', '{}');

CREATE TABLE `fine_types_doj` (
  
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `label` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  
  PRIMARY KEY (`id`)
);

INSERT INTO `fine_types_mafia` (label, amount, category) VALUES 
	('Pflichtverteidiger',3000,0),
	('Anwalt + Prozess',5000,0),
	('Anwalt + Anklage',10000,1),
	('Anwalt + Dienstaufsichtsbeschwerde',20000,1);
;